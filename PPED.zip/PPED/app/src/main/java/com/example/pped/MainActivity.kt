package com.example.pped

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuth.AuthStateListener
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.GoogleAuthProvider


class MainActivity : AppCompatActivity() {
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var authStateListener: AuthStateListener
    private lateinit var client:GoogleSignInClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val LoginButton : Button = findViewById(R.id.LoginButton)
        val Emailtext : TextView = findViewById(R.id.emailtext)
        val PasswordText : TextView = findViewById(R.id.passwordText)
        val btnRegistro : Button = findViewById(R.id.singUpButton)
        val btngoogle : Button = findViewById(R.id.GoogleSignIn)
        val options = GoogleSignInOptions.Builder().requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        client = GoogleSignIn.getClient(this,options)

        btngoogle.setOnClickListener{
            val intent = client.signInIntent
            startActivityForResult(intent,10001)
        }




        LoginButton.setOnClickListener(){

            signIn(Emailtext.text.toString(),PasswordText.text.toString())

        }
        btnRegistro.setOnClickListener(){
            val i = Intent(this,crearcuenta::class.java)
            startActivity(i)
        }


    }

    private fun signIn(email:String, password:String)
    {
        firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this){
            task ->
            if(task.isSuccessful){
                val user = firebaseAuth.currentUser
                Toast.makeText(baseContext,"Auntentificacion exitosa",Toast.LENGTH_SHORT).show()
                val i = Intent(this, MainActivity2::class.java)
                startActivity(i)
            }
            else{
                Toast.makeText(baseContext,"Error de Usuario y/o Contraseña",Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode==10001){
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account = task.getResult(ApiException::class.java)
            val credential = GoogleAuthProvider.getCredential(account.idToken,null)
            FirebaseAuth.getInstance().signInWithCredential(credential)
                .addOnCompleteListener {task->
                    if(task.isSuccessful){
                            val i = Intent(this,MainActivity2::class.java)
                            startActivity(i)
                        }else{
                            Toast.makeText(this,task.exception?.message,Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

}








